const EN = {
    header:{
        home:'Home',
        news:'News',
        // projects:'Our Projects',
        services:'Our Services',
        contacts:'Contacts',
    },
    homepage:{
        title:'Creating spaces you love to live in',
        subtitle:'We provide construction, landscaping and communal services, combining reliability, comfort and aesthetics to create better living environments',
        button1:'Discover More',
        button2:'Get Started Now'
    },

    benefits:{
        title:'Our Construction Benefits',
        subtitle:'We offer innovative solutions that not only enhance enviromental sustainability but also drive economic efficiency',
    },

    services:{
        title:'Providing Best Services',
        subtitle_lg:'We are committed to sustainable construction practices that minimize environmental impact. From energy-efficient materials to eco-friendly designs, we create spaces that are both functional and responsible.',
        subtitle:'We are committed to sustainable construction practices that minimize environmental impact.',
    },

    process:{
        title:'Our projects',
        subtitle_lg:'We specialize in construction, installation and design works, delivering residential, industrial and infrastructure projects. Alongside our construction activities, the company is developing a multifunctional livestock complex and operates in the wholesale and retail pharmaceutical sector. By implementing projects across diverse fields, we create modern facilities and expand production capacities, contributing to the economic and infrastructure development of Turkmenistan',
        subtitle:'We specialize in construction and design, develop livestock production and pharmaceutical activities, creating modern facilities and contributing to the development of Turkmenistan'
    },

    testimonials:{
        title:'News',
        loadMore:'Show more',
        loading:'Loading...',
        backHome:'Back to homepage',
        moreNews:'More news',
        readMore:'Read more...',
    },

    footer:{
        title:'Ready to Work With Us?',
        subtitle_lg:'Let’s bring your construction project to life. Contact us for a free consultation, and discover how we can help turn your vision into reality',
        subtitle:'Experience top-notch customer service and let us guide you on your real estate journey',
        description:'Search properties, schedule a tour, and start your journey with expert guidance every step of the way',
        placeholder:'Insert your email here...',
        button:'Submit',
        home:'Home',
        aboutUs:'About us',
        collection:'Collection',
        blogNews:'Blog & News',
        socials:'Socials',
        instagram:'Instagram',
        facebook:'Facebook',
        tiktok:'Tiktok',
        security:'Security',
        privacy:'Privacy Policy',
        copyrights:'Copyrights',
        userAgreements:'User Agreements',
    }
} 


export default EN;